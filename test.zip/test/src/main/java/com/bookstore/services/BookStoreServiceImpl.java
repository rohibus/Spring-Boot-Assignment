package com.bookstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookstore.model.Book;
import com.bookstore.model.LovedBook;
import com.bookstore.model.ReadLater;
import com.bookstore.repository.BookStoreRepo;
import com.bookstore.repository.LovedBookRepo;
import com.bookstore.repository.ReadLaterRepo;

@Service
public class BookStoreServiceImpl implements BookStoreService {

	@Autowired
	BookStoreRepo bookStoreRepo;

	@Autowired
	LovedBookRepo lovedBookRepo;

	@Autowired
	ReadLaterRepo readLaterRepo;

	public List<Book> getAllBooks() {
		return bookStoreRepo.findAll();
	}

	public List<Book> getBooksByAuthorName(String name) {
		return bookStoreRepo.getBooksByAuthorName(name);
	}

	@Override
	public List<Book> getBooksByTitle(String tiltle) {
		return bookStoreRepo.getBooksByTitle(tiltle);
	}

	@Override
	public List<Book> getBooksByPublication(String publication) {
		return bookStoreRepo.getBooksByPublication(publication);
	}

	@Override
	public Book getBooksById(Long id) {
		return bookStoreRepo.findById(id).get();
	}

	public void addToLovedBook(LovedBook book) {
		lovedBookRepo.save(book);
	}

	public void addReadLater(ReadLater ReadLater) {
		readLaterRepo.save(ReadLater);
	}

	@Override
	public void addBook(Book book) {
		bookStoreRepo.save(book);
	}

	@Override
	public void removeBook(Book book) {
		bookStoreRepo.delete(book);
	}

	@Override
	public void updateBook(Book book) {
		bookStoreRepo.save(book);

	}

}
