package com.bookstore.services;

import java.util.List;

import com.bookstore.model.Book;
import com.bookstore.model.LovedBook;
import com.bookstore.model.ReadLater;

public interface BookStoreService {

	public List<Book> getAllBooks();
	
	public List<Book> getBooksByAuthorName(String name);

	public List<Book> getBooksByTitle(String tiltle);

	public List<Book> getBooksByPublication(String publication);

	public Book getBooksById(Long id);
	
	public void addToLovedBook(LovedBook book);

	public void addReadLater(ReadLater ReadLater);
	
	public void addBook(Book book);
	
	public void removeBook(Book book);
	
	public void updateBook(Book book);

}
