package com.bookstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bookstore.model.Book;
import com.bookstore.model.LovedBook;
import com.bookstore.model.ReadLater;
import com.bookstore.services.BookStoreService;

@RestController
@RequestMapping(value = "/bookstore")
public class BookStoreController {

	@Autowired
	BookStoreService bookStoreService;

	@RequestMapping(value = "/getAllBooks", method = RequestMethod.GET)
	public List<Book> getAllBooks() {
		return bookStoreService.getAllBooks();
	}

	@RequestMapping(value = "/getBooksByAuthorName", method = RequestMethod.POST)
	public List<Book> getBooksByAuthorName(String authorName) {
		return bookStoreService.getBooksByAuthorName(authorName);
	}
	
	@RequestMapping(value = "/getBooksByPublication", method = RequestMethod.POST)
	public List<Book> getBooksByPublication(String publication) {
		return bookStoreService.getBooksByPublication(publication);
	}
	
	@RequestMapping(value = "/getBooksByTitle", method = RequestMethod.POST)
	public List<Book> getBooksByTitle(String tiltle) {
		return bookStoreService.getBooksByTitle(tiltle);
	}
		
	@RequestMapping(value = "/getBooksById/{id}", method = RequestMethod.GET)
	public Book getLovedBooksByUserId(@PathVariable Long id) {
		return bookStoreService.getBooksById(id);
	}
	
	@RequestMapping(value = "/addLovedBook", method = RequestMethod.POST)
	public void addLovedBook(@RequestBody LovedBook lovedBook) {
		bookStoreService.addToLovedBook(lovedBook);
	}

	@RequestMapping(value = "/addToReadLater", method = RequestMethod.POST)
	public void addLovedBook(@RequestBody ReadLater readLater) {
		bookStoreService.addReadLater(readLater);
	}
	
	@RequestMapping(value = "/addBook", method = RequestMethod.POST)
	public void addBook(@RequestBody Book book) {
		bookStoreService.addBook(book);
	}
	
	@RequestMapping(value = "/removeBook", method = RequestMethod.POST)
	public void removeBook(@RequestBody Book book) {
		bookStoreService.removeBook(book);
	}
	
	@RequestMapping(value = "/updateBook", method = RequestMethod.POST)
	public void updateBook(@RequestBody Book book) {
		bookStoreService.updateBook(book);
	}

}
